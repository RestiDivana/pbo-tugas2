<?php
class BangunDatar {
    public function hitungLuas() {
        return 0;
    }
}

class Persegi extends BangunDatar {
    private $sisi;

    public function __construct($sisi) {
        $this->sisi = $sisi;
    }

    public function hitungLuas() {
        return $this->sisi * $this->sisi;
    }
}

class PersegiPanjang extends BangunDatar {
    private $panjang;
    private $lebar;

    public function __construct($panjang, $lebar) {
        $this->panjang = $panjang;
        $this->lebar = $lebar;
    }

    public function hitungLuas() {
        return $this->panjang * $this->lebar;
    }
}

class Segitiga extends BangunDatar {
    private $alas;
    private $tinggi;

    public function __construct($alas, $tinggi) {
        $this->alas = $alas;
        $this->tinggi = $tinggi;
    }

    public function hitungLuas() {
        return 0.5 * $this->alas * $this->tinggi;
    }
}

class Lingkaran extends BangunDatar {
    private $radius;

    public function __construct($radius) {
        $this->radius = $radius;
    }

    public function hitungLuas() {
        return M_PI * $this->radius * $this->radius;
    }
}

$luas = 0;

if (isset($_POST['submit'])) {
    $jenisBangunDatar = $_POST['jenis_bangun_datar'];

    if ($jenisBangunDatar == 'persegi') {
        $sisi = $_POST['sisi'];
        $bangunDatar = new Persegi($sisi);
        $luas = $bangunDatar->hitungLuas();
    } elseif ($jenisBangunDatar == 'persegi_panjang') {
        $panjang = $_POST['panjang'];
        $lebar = $_POST['lebar'];
        $bangunDatar = new PersegiPanjang($panjang, $lebar);
        $luas = $bangunDatar->hitungLuas();
    } elseif ($jenisBangunDatar == 'segitiga') {
        $alas = $_POST['alas'];
        $tinggi = $_POST['tinggi'];
        $bangunDatar = new Segitiga($alas, $tinggi);
        $luas = $bangunDatar->hitungLuas();
    } elseif ($jenisBangunDatar == 'lingkaran') {
        $radius = $_POST['radius'];
        $bangunDatar = new Lingkaran($radius);
        $luas = $bangunDatar->hitungLuas();
    }
}
?>

<!DOCTYPE html>
<html>

<head>
  <title>Kalkulator Luas Bangun Datar</title>
</head>

<body>
  <h1>Kalkulator Luas Bangun Datar</h1>
  <form method="post">
    <label for="jenis_bangun_datar">Pilih Jenis Bangun Datar:</label>
    <select name="jenis_bangun_datar" id="jenis_bangun_datar">
      <option value="persegi">Persegi</option>
      <option value="persegi_panjang">Persegi Panjang</option>
      <option value="segitiga">Segitiga</option>
      <option value="lingkaran">Lingkaran</option>
    </select>

    <div id="input_fields">
      <!-- Tampilkan bidang input sesuai dengan jenis yang dipilih -->
      <div id="persegi_fields">
        <label for="sisi">Sisi (Persegi):</label>
        <input type="number" name="sisi" id="sisi">
      </div>

      <div id="persegi_panjang_fields">
        <label for="panjang">Panjang (Persegi Panjang):</label>
        <input type="number" name="panjang" id="panjang">

        <label for="lebar">Lebar (Persegi Panjang):</label>
        <input type="number" name="lebar" id="lebar">
      </div>

      <div id="segitiga_fields">
        <label for="alas">Alas (Segitiga):</label>
        <input type="number" name="alas" id="alas">

        <label for="tinggi">Tinggi (Segitiga):</label>
        <input type="number" name="tinggi" id="tinggi">
      </div>

      <div id="lingkaran_fields">
        <label for="radius">Radius (Lingkaran):</label>
        <input type="number" name="radius" id="radius">
      </div>
    </div>

    <input type="submit" name="submit" value="Hitung Luas">
  </form>

  <?php if (isset($_POST['submit'])): ?>
  <p>Luas Bangun Datar: <?php echo $luas; ?></p>
  <?php endif; ?>

  <script type="text/javascript">
    // Tampilkan atau sembunyikan bidang input berdasarkan jenis bangun datar yang dipilih
    document.getElementById("jenis_bangun_datar").addEventListener("change", function () {
      var jenisBangunDatar = this.value;
      document.getElementById("persegi_fields").style.display = (jenisBangunDatar === "persegi") ? "block" : "none";
      document.getElementById("persegi_panjang_fields").style.display = (jenisBangunDatar === "persegi_panjang") ?
        "block" : "none";
      document.getElementById("segitiga_fields").style.display = (jenisBangunDatar === "segitiga") ? "block" :
        "none";
      document.getElementById("lingkaran_fields").style.display = (jenisBangunDatar === "lingkaran") ? "block" :
        "none";
    });
  </script>
</body>

</html>