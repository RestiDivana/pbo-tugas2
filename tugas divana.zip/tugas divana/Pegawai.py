import tkinter as tk

frame_tambahan = None
entry_jam_kerja = None
entry_tunjangan = None
entry_upah_per_jam = None
entry_durasi_kontrak = None  # Definisikan variabel secara global

gaji_pegawai = None

class Pegawai(object):
    def __init__(self, nama, gaji):
        self.nama = nama
        self.gaji = gaji

    def hitung_gaji(self):
        return self.gaji

class PegawaiTetap(Pegawai):
    def __init__(self, nama, gaji, tunjangan):
        super(PegawaiTetap, self).__init__(nama, gaji)
        self.tunjangan = tunjangan

    def hitung_gaji(self):
        return self.gaji + self.tunjangan

class PegawaiHarian(Pegawai):
    def __init__(self, nama, gaji, jam_kerja, upah_per_jam):
        super(PegawaiHarian, self).__init__(nama, gaji)
        self.jam_kerja = jam_kerja
        self.upah_per_jam = upah_per_jam

    def hitung_gaji(self):
        return self.gaji + (self.jam_kerja * self.upah_per_jam)

class PegawaiKontrak(Pegawai):
    def __init__(self, nama, gaji, durasi_kontrak):
        super(PegawaiKontrak, self).__init__(nama, gaji)
        self.durasi_kontrak = durasi_kontrak

    def hitung_gaji(self):
        return self.gaji

def create_main_window():
    global gaji_pegawai, entry_durasi_kontrak
    root = tk.Tk()
    root.title("Perhitungan Gaji Pegawai")

    def hitung_gaji_pegawai():
        nama = entry_nama.get()

        if combo_jenis_pegawai.get() == "Pegawai Tetap":
            gaji = float(entry_gaji.get())
            try:
                tunjangan = float(entry_tunjangan.get())
            except ValueError:
                tunjangan = 0.0
            pegawai = PegawaiTetap(nama, gaji, tunjangan)
        elif combo_jenis_pegawai.get() == "Pegawai Harian":
            gaji = float(entry_gaji.get())
            try:
                jam_kerja = float(entry_jam_kerja.get())
                upah_per_jam = float(entry_upah_per_jam.get())
            except ValueError:
                jam_kerja = 0.0
                upah_per_jam = 0.0
            pegawai = PegawaiHarian(nama, gaji, jam_kerja, upah_per_jam)
        else:
            try:
                durasi_kontrak = float(entry_durasi_kontrak.get())
            except ValueError:
                durasi_kontrak = 0
            gaji = float(entry_gaji.get())  # Menggunakan gaji dasar
            pegawai = PegawaiKontrak(nama, gaji, durasi_kontrak)

        total_gaji = pegawai.hitung_gaji()
        gaji_pegawai.set("Total Gaji {}: {}".format(nama, total_gaji))
        label_total_gaji.config(text="Total Gaji {}: {}".format(nama, total_gaji))

    label_nama = tk.Label(root, text="Nama Pegawai:")
    label_nama.pack()
    entry_nama = tk.Entry(root)
    entry_nama.pack()

    label_gaji = tk.Label(root, text="Gaji Dasar:")
    label_gaji.pack()
    entry_gaji = tk.Entry(root)
    entry_gaji.pack()

    label_jenis_pegawai = tk.Label(root, text="Jenis Pegawai:")
    label_jenis_pegawai.pack()
    jenis_pegawai_options = ["Pegawai Tetap", "Pegawai Harian", "Pegawai Kontrak"]
    combo_jenis_pegawai = tk.StringVar()
    combo_jenis_pegawai.set(jenis_pegawai_options[0])
    dropdown_jenis_pegawai = tk.OptionMenu(root, combo_jenis_pegawai, *jenis_pegawai_options)
    dropdown_jenis_pegawai.pack()

    gaji_pegawai = tk.StringVar()
    label_gaji_pegawai = tk.Label(root, textvariable=gaji_pegawai)
    label_gaji_pegawai.pack()

    def update_tampilan():
        global frame_tambahan, entry_jam_kerja, entry_tunjangan, entry_upah_per_jam, entry_durasi_kontrak

        if frame_tambahan:
            frame_tambahan.destroy()

        frame_tambahan = tk.Frame(root)
        frame_tambahan.pack()

        if combo_jenis_pegawai.get() == "Pegawai Tetap":
            label_tunjangan = tk.Label(frame_tambahan, text="Tunjangan:")
            label_tunjangan.pack()
            entry_tunjangan = tk.Entry(frame_tambahan)
            entry_tunjangan.pack()
        elif combo_jenis_pegawai.get() == "Pegawai Harian":
            label_jam_kerja = tk.Label(frame_tambahan, text="Jam Kerja:")
            label_jam_kerja.pack()
            entry_jam_kerja = tk.Entry(frame_tambahan)
            entry_jam_kerja.pack()

            label_upah_per_jam = tk.Label(frame_tambahan, text="Upah per Jam:")
            label_upah_per_jam.pack()
            entry_upah_per_jam = tk.Entry(frame_tambahan)
            entry_upah_per_jam.pack()
        else:
            label_durasi_kontrak = tk.Label(frame_tambahan, text="Durasi Kontrak (bulan):")
            label_durasi_kontrak.pack()
            entry_durasi_kontrak = tk.Entry(frame_tambahan)
            entry_durasi_kontrak.pack()

    combo_jenis_pegawai.trace("w", lambda *args: update_tampilan())
    update_tampilan()

    button_hitung = tk.Button(root, text="Hitung Gaji", command=hitung_gaji_pegawai)
    button_hitung.pack()

    label_total_gaji = tk.Label(root, text="Total Gaji: 0.0")
    label_total_gaji.pack()

    root.mainloop()

if __name__ == "__main__":
    create_main_window()
