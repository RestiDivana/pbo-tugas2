#include <iostream>
#include <string>

class BangunDatar {
public:
    virtual double hitungLuas() const = 0;
    virtual double hitungKeliling() const = 0;
};

class Persegi : public BangunDatar {
private:
    double sisi;

public:
    Persegi(double sisi) : sisi(sisi) {}

    double hitungLuas() const override {
        return sisi * sisi;
    }

    double hitungKeliling() const override {
        return 4 * sisi;
    }
};

class PersegiPanjang : public BangunDatar {
private:
    double panjang;
    double lebar;

public:
    PersegiPanjang(double panjang, double lebar) : panjang(panjang), lebar(lebar) {}

    double hitungLuas() const override {
        return panjang * lebar;
    }

    double hitungKeliling() const override {
        return 2 * (panjang + lebar);
    }
};

class Segitiga : public BangunDatar {
private:
    double alas;
    double tinggi;

public:
    Segitiga(double alas, double tinggi) : alas(alas), tinggi(tinggi) {}

    double hitungLuas() const override {
        return 0.5 * alas * tinggi;
    }

    double hitungKeliling() const override {
        // Ini adalah implementasi sederhana, asumsi sama sisi
        return 3 * alas;
    }
};

class Lingkaran : public BangunDatar {
private:
    double jariJari;

public:
    Lingkaran(double jariJari) : jariJari(jariJari) {}

    double hitungLuas() const override {
        return 3.14 * jariJari * jariJari;
    }

    double hitungKeliling() const override {
        return 2 * 3.14 * jariJari;
    }
};

int main() {
    std::string jenis;
    std::cout << "Pilih jenis bangun datar (persegi/persegi_panjang/segitiga/lingkaran): ";
    std::cin >> jenis;

    BangunDatar* bangunDatar = nullptr;

    if (jenis == "persegi") {
        double sisi;
        std::cout << "Masukkan panjang sisi: ";
        std::cin >> sisi;
        bangunDatar = new Persegi(sisi);
    } else if (jenis == "persegi_panjang") {
        double panjang, lebar;
        std::cout << "Masukkan panjang dan lebar: ";
        std::cin >> panjang >> lebar;
        bangunDatar = new PersegiPanjang(panjang, lebar);
    } else if (jenis == "segitiga") {
        double alas, tinggi;
        std::cout << "Masukkan alas dan tinggi: ";
        std::cin >> alas >> tinggi;
        bangunDatar = new Segitiga(alas, tinggi);
    } else if (jenis == "lingkaran") {
        double jariJari;
        std::cout << "Masukkan jari-jari lingkaran: ";
        std::cin >> jariJari;
        bangunDatar = new Lingkaran(jariJari);
    } else {
        std::cout << "Jenis bangun datar tidak valid.\n";
        return 1;
    }

    double luas = bangunDatar->hitungLuas();
    double keliling = bangunDatar->hitungKeliling();

    std::cout << "Luas: " << luas << std::endl;
    std::cout << "Keliling: " << keliling << std::endl;

    delete bangunDatar;

    return 0;
}
